﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Threading.Tasks;

namespace TagHelperSamples.Bootstrap3
{
    public class ModalContext
    {
        public IHtmlContent ModalBody { get; set; }
        public IHtmlContent ModalFooter { get; set; }
    }
    public enum Transitions { none, face, bounce, bounceIn, bounceUpIn, bounceDownIn, bounceLeftIn, bounceRightIn, flash, fadeIn, flipXIn, flipYIn, flipBounceXIn, flipBounceYIn, swoopIn, whirlIn, shrinkIn, expandIn, slideUpIn, slideDownIn, slideLeftIn, slideRightIn, slideUpBigIn, slideDownBigIn, slideLeftBigIn, slideRightBigIn, perspectiveUpIn, perspectiveDownIn, perspectiveLeftIn, perspectiveRightIn, shake, tada, swing, pulse };
    
    /// <summary>
    /// Bootstrap3 modal dialog
    /// </summary>
    [RestrictChildren("modal-body", "modal-footer")]
    public class ModalTagHelper : TagHelper
    {

        /// <summary>
        /// The Id of the modal
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// The title of the modal
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// The transition effect
        /// </summary>
        public Transitions Trans { get; set; }

        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {
            var modalContext = new ModalContext();
            context.Items.Add(typeof(ModalTagHelper), modalContext);

            await output.GetChildContentAsync();

            var modalUniqueId = context.UniqueId;

            var template =
            $@"<div class='modal-dialog' role='document'>
                <div class='modal-content'>
                  <div class='modal-header'>
                    <button type = 'button' class='close' data-dismiss='modal' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <h4 class='modal-title' id='{modalUniqueId}Label'>{Title}</h4>
                  </div>
                    <div class='modal-body'>";

            output.TagName = "div";

            output.Attributes.SetAttribute("tabindex", "-1");
            output.Attributes.SetAttribute("role", "dialog");
            output.Attributes.SetAttribute("id", Id);
            output.Attributes.SetAttribute("aria-labelledby", $"{modalUniqueId}Label");

            var className = "modal";
            if (output.Attributes.ContainsName("class"))
            {
                className = string.Format("{0} {1}", output.Attributes["class"].Value, className);
            }
            output.Attributes.SetAttribute("class", className);

            if (Trans != Transitions.none)
            {
                output.Attributes.SetAttribute("data-easein", Trans);
            }

            output.Content.AppendHtml(template);
            if (modalContext.ModalBody != null)
            {
                output.Content.AppendHtml(modalContext.ModalBody);
            }
            output.Content.AppendHtml("</div>");
            if (modalContext.ModalFooter != null)
            {
                output.Content.AppendHtml(
                    $@"<div class='modal-footer'>
                            {modalContext.ModalFooter}
                        </div>");
            }

            output.Content.AppendHtml("</div></div>");
        }
    }
}
