﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TagHelperSamples.Misc
{
    [HtmlTargetElement("email")]
    public class EmailTagHelper : TagHelper
    {

        //Please remember Pascal-case property names are switch to lower kebab case
        //Example:  EmailName = email-name
        public string EmailName { get; set; }

        public override async void Process(TagHelperContext context, TagHelperOutput output)
        {
            //Changes the output tag from <email> to <a>
            output.TagName = "a";

            //Make A Tag not selfclosing
            output.TagMode = TagMode.StartTagAndEndTag;

            //Get Content in HTML tag
            var childContent = output.Content.IsModified ? output.Content.GetContent() :
            (await output.GetChildContentAsync()).GetContent();

            //Sets href
            output.Attributes.SetAttribute("href", "mailto:" + childContent);

            //Display Name or email address in link text.
            if (EmailName != "" && EmailName != null) 
            {
                output.Content.SetContent(EmailName);
            }
            else
            {
                //Optional since it's already the content
                output.Content.SetContent(childContent);
            }

        }
    }
}
